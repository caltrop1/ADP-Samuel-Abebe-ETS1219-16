import javafx.application.Application;
import javafx.stage.Stage;
import javafx.stage.FileChooser;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;

import org.fxmisc.richtext.CodeArea;
import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.StyleSpansBuilder;
//import org.fxmisc.flowless.Virtualized;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main extends Application {

    private TextArea textArea;
    private CodeArea codeArea;

    private File currentFile;
    private boolean isPythonFile = false;

    private static final List<String> PYTHON_KEYWORDS = Arrays.asList(
            "False", "None", "True", "and", "as",
            "assert", "async", "await", "break", "class",
            "continue", "def", "del", "elif", "else",
            "except", "finally", "for", "from", "global",
            "if", "import", "in", "is", "lambda",
            "nonlocal", "not", "or", "pass", "raise",
            "return", "try", "while", "with", "yield"

    );

    private static final Pattern WORD_PATTERN = Pattern.compile("\\b\\w+\\b");

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {

        textArea = new TextArea();
        textArea.setWrapText(true);

        codeArea = new CodeArea();
        codeArea.setWrapText(true);
        codeArea.setVisible(false);

        // live highlighting
        codeArea.textProperty().addListener((obs, oldText, newText) -> {
            highlightPython();
        });
        codeArea.getStylesheets().add(
                getClass().getResource("/editor.css").toExternalForm()
        );

        StackPane editorStack = new StackPane(textArea, codeArea);

        Button openButton = new Button("Open");
        Button saveButton = new Button("Save");

        openButton.setOnAction(e -> openFile(stage));
        saveButton.setOnAction(e -> saveFile(stage));

        HBox toolbar = new HBox(10, openButton, saveButton);

        BorderPane root = new BorderPane();
        root.setTop(toolbar);
        root.setCenter(editorStack);

        Scene scene = new Scene(root, 700, 500);
        stage.setScene(scene);
        stage.setTitle("Simple Notepad Clone");
        stage.show();
    }

    private void openFile(Stage stage) {
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Open File");
        chooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Text and Python files", "*.txt", "*.py")
        );

        File file = chooser.showOpenDialog(stage);
        if (file != null) {
            loadFile(file);
        }
    }

    private void loadFile(File file) {
        try {
            String text = Files.readString(file.toPath());

            currentFile = file;
            isPythonFile = file.getName().toLowerCase().endsWith(".py");

            if (isPythonFile) {
                textArea.setVisible(false);
                codeArea.setVisible(true);
                codeArea.replaceText(text);
                highlightPython();
            } else {
                codeArea.setVisible(false);
                textArea.setVisible(true);
                textArea.setText(text);
            }

        } catch (IOException e) {
            System.out.println("Failed to open file: " + e.getMessage());
        }
    }

    private void saveFile(Stage stage) {
        if (currentFile == null) {
            FileChooser chooser = new FileChooser();
            chooser.setTitle("Save File");
            chooser.getExtensionFilters().add(
                    new FileChooser.ExtensionFilter("Text and Python files", "*.txt", "*.py")
            );

            File file = chooser.showSaveDialog(stage);
            if (file == null) return;

            currentFile = file;
        }

        writeFile(currentFile);
    }

    private void writeFile(File file) {
        try {
            String content = isPythonFile
                    ? codeArea.getText()
                    : textArea.getText();

            Files.write(file.toPath(), content.getBytes());

            currentFile = file;
            isPythonFile = file.getName().toLowerCase().endsWith(".py");

        } catch (IOException e) {
            System.out.println("Failed to save file: " + e.getMessage());
        }
    }

    private void highlightPython() {
        String text = codeArea.getText();

        StyleSpansBuilder<Collection<String>> builder = new StyleSpansBuilder<>();

        Matcher matcher = WORD_PATTERN.matcher(text);
        int lastEnd = 0;

        while (matcher.find()) {

            builder.add(Collections.emptyList(),
                    matcher.start() - lastEnd);

            String word = matcher.group();

            if (PYTHON_KEYWORDS.contains(word)) {
                builder.add(Collections.singleton("keyword"),
                        matcher.end() - matcher.start());
            } else {
                builder.add(Collections.emptyList(),
                        matcher.end() - matcher.start());
            }

            lastEnd = matcher.end();
        }

        builder.add(Collections.emptyList(),
                text.length() - lastEnd);

        codeArea.setStyleSpans(0, builder.create());
    }
}